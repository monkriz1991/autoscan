import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

gsap.registerPlugin(ScrollTrigger);

export default function InterfaceSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".interface-animate", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 65%",
          toggleActions: "play none none none",
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="bg-dark py-24 lg:py-32"
      id="interface"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="interface-animate text-caption text-accent-orange block">
            INTERFACE
          </span>
          <h2 className="interface-animate text-h3 text-white mt-3">
            Fault codes and AI chat — one screen
          </h2>
          <p className="interface-animate text-body-large text-text-muted max-w-[600px] mx-auto mt-4">
            See what's wrong, read live data, and ask the bot follow-up
            questions without switching windows. Everything you need to decide
            on repairs stays in one place.
          </p>
        </div>

        {/* Real app screenshot */}
        <div className="interface-animate relative max-w-[1100px] mx-auto">
          <div className="rounded-xl overflow-hidden shadow-2xl border border-white/10">
            <img
              src="/hero-slide-diagnostics.png"
              alt="AIscanAuto real interface showing DTC trouble codes P0420, P0171, P0128 and GearNrid AI assistant chat"
              className="w-full h-auto"
              loading="lazy"
            />
          </div>
          {/* Annotation labels */}
          <div className="absolute top-[15%] left-[5%] bg-accent-blue/90 text-white text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm">
            Trouble Codes (DTCs)
          </div>
          <div className="absolute top-[15%] right-[5%] bg-accent-orange/90 text-white text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm">
            AI Assistant Chat
          </div>
        </div>

        {/* Feature bullets */}
        <div className="interface-animate grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-[900px] mx-auto mt-12">
          {[
            "Scan & clear DTC codes instantly",
            "AI explains codes in plain English",
            "Chat history saves every session",
          ].map((text, i) => (
            <div
              key={i}
              className="flex items-center gap-3 text-text-muted"
            >
              <span className="w-2 h-2 rounded-full bg-accent-blue shrink-0" />
              <span className="text-[15px]">{text}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="interface-animate text-center mt-10">
          <Link
            to="/download"
            className="inline-flex items-center gap-2 text-accent-blue hover:underline transition-all"
          >
            <span className="text-base">Download the app</span>
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
