import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, ArrowRight } from "lucide-react";

const dtcCodes = [
  { code: "P0420", desc: "Catalyst System Efficiency Below Threshold (Bank 1)", category: "Emissions" },
  { code: "P0300", desc: "Random/Multiple Cylinder Misfire Detected", category: "Ignition" },
  { code: "P0171", desc: "System Too Lean (Bank 1)", category: "Fuel" },
  { code: "P0172", desc: "System Too Rich (Bank 1)", category: "Fuel" },
  { code: "P0442", desc: "EVAP System Leak Detected (Small Leak)", category: "Emissions" },
  { code: "P0455", desc: "EVAP System Leak Detected (Gross Leak)", category: "Emissions" },
  { code: "P0401", desc: "Exhaust Gas Recirculation Flow Insufficient", category: "Emissions" },
  { code: "P0128", desc: "Coolant Temperature Below Thermostat Regulating Temperature", category: "Cooling" },
  { code: "P0301", desc: "Cylinder 1 Misfire Detected", category: "Ignition" },
  { code: "P0302", desc: "Cylinder 2 Misfire Detected", category: "Ignition" },
  { code: "P0303", desc: "Cylinder 3 Misfire Detected", category: "Ignition" },
  { code: "P0304", desc: "Cylinder 4 Misfire Detected", category: "Ignition" },
  { code: "P0135", desc: "O2 Sensor Heater Circuit (Bank 1, Sensor 1)", category: "Sensor" },
  { code: "P0141", desc: "O2 Sensor Heater Circuit (Bank 1, Sensor 2)", category: "Sensor" },
  { code: "P0440", desc: "EVAP Emission Control System Malfunction", category: "Emissions" },
  { code: "P0325", desc: "Knock Sensor 1 Circuit Malfunction (Bank 1)", category: "Sensor" },
  { code: "P0101", desc: "Mass Air Flow (MAF) Circuit Range/Performance", category: "Sensor" },
  { code: "P0113", desc: "Intake Air Temperature (IAT) Circuit High Input", category: "Sensor" },
  { code: "P0500", desc: "Vehicle Speed Sensor Malfunction", category: "Sensor" },
  { code: "P0600", desc: "Serial Communication Link Malfunction", category: "Computer" },
  { code: "P0700", desc: "Transmission Control System Malfunction", category: "Transmission" },
  { code: "P0340", desc: "Camshaft Position Sensor Circuit Malfunction", category: "Sensor" },
  { code: "P0335", desc: "Crankshaft Position Sensor A Circuit Malfunction", category: "Sensor" },
  { code: "P0562", desc: "System Voltage Low", category: "Electrical" },
];

const catColors: Record<string, string> = {
  Emissions: "bg-rose-500",
  Ignition: "bg-orange-500",
  Fuel: "bg-amber-500",
  Cooling: "bg-sky-500",
  Sensor: "bg-violet-500",
  Computer: "bg-slate-500",
  Transmission: "bg-teal-500",
  Electrical: "bg-yellow-500",
};

export default function DTCSection() {
  const [search, setSearch] = useState("");

  const filtered = dtcCodes.filter(
    (d) =>
      d.code.toLowerCase().includes(search.toLowerCase()) ||
      d.desc.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section className="bg-dark py-20 lg:py-24" id="dtc-codes">
      <div className="max-w-[1000px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center">
          <span className="text-caption text-accent-orange">DTC CODES</span>
          <h2 className="text-h3 text-white mt-3">Popular OBD2 fault codes</h2>
          <p className="text-text-muted mt-3 max-w-[540px] mx-auto">
            Quick reference to the most common check-engine codes. Click any code
            for full details, causes, and diagnosis steps.
          </p>
        </div>

        {/* Search */}
        <div className="relative mt-8 max-w-[400px] mx-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={18} />
          <input
            type="text"
            placeholder="Search codes (e.g. P0420)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-dark-surface border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
          />
        </div>

        {/* Code cards grid — 4 columns on desktop */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 mt-10">
          {filtered.map((dtc, i) => (
            <Link
              key={i}
              to={`/dtc-codes/${dtc.code}`}
              className="bg-dark-surface rounded-xl p-4 hover:-translate-y-0.5 transition-all duration-200 hover:shadow-glow group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-display text-lg font-bold text-white group-hover:text-accent-blue transition-colors">
                  {dtc.code}
                </span>
                <span className={`${catColors[dtc.category] || "bg-gray-500"} text-white text-[10px] font-bold px-2 py-0.5 rounded-full`}>
                  {dtc.category}
                </span>
              </div>
              <p className="text-text-muted text-xs leading-snug line-clamp-2">
                {dtc.desc}
              </p>
            </Link>
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-text-muted mt-8">No codes match "{search}"</p>
        )}

        {/* CTA */}
        <div className="text-center mt-10">
          <Link
            to="/dtc-codes"
            className="inline-flex items-center gap-2 text-accent-blue hover:underline text-sm"
          >
            Browse all DTC codes
            <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    </section>
  );
}
