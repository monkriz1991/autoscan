import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Monitor, Apple } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

/* ─── Linux icon ─── */
function LinuxIcon({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
      <path d="M12.504 0c-.155 0-.315.008-.48.021-4.226.333-3.105 4.807-3.17 6.298-.076 1.092-.3 1.953-1.05 3.02-.885 1.051-2.127 2.75-2.716 4.521-.278.832-.41 1.684-.287 2.489a.424.424 0 00-.11.135c-.26.268-.45.6-.663.839-.199.199-.485.267-.797.4-.313.136-.658.269-.864.68-.09.189-.136.394-.132.602 0 .199.027.4.055.536.058.399.116.728.04.97-.249.68-.28 1.145-.106 1.484.174.334.535.47.94.601.81.2 1.91.135 2.774.6.926.466 1.866.67 2.616.47.526-.116.97-.464 1.208-.946.587-.003 1.23-.269 2.26-.334.699-.058 1.574.267 2.577.2.025.134.063.198.114.333l.003.003c.391.778 1.113 1.132 1.884 1.071.771-.06 1.592-.536 2.257-1.306.631-.765 1.683-1.084 2.378-1.503.348-.199.629-.469.649-.853.023-.4-.2-.811-.714-1.376v-.097l-.003-.003c-.17-.2-.25-.535-.338-.926-.085-.401-.182-.786-.492-1.046h-.003c-.059-.054-.123-.067-.188-.135a.357.357 0 00-.19-.064c.431-1.278.264-2.55-.173-3.694-.533-1.41-1.465-2.638-2.175-3.483-.796-1.005-1.576-1.957-1.56-3.368.026-2.152.236-6.133-3.544-6.139zm.529 3.405h.013c.213 0 .396.062.584.198.19.135.33.332.438.533.105.259.158.459.166.724 0-.02.006-.04.006-.06v.105a.086.086 0 01-.004-.021l-.004-.024a1.807 1.807 0 01-.15.706.953.953 0 01-.213.335.71.71 0 00-.088-.042c-.104-.045-.198-.064-.284-.133a1.312 1.312 0 00-.22-.066c.05-.06.146-.133.183-.198.053-.128.082-.264.088-.402v-.02a1.21 1.21 0 00-.061-.4c-.045-.134-.101-.2-.183-.333-.084-.066-.167-.132-.267-.132h-.016c-.093 0-.176.03-.262.132a.8.8 0 00-.205.334 1.18 1.18 0 00-.09.41c.007.135.034.269.08.395.045.125.135.195.18.266.048.065.058.11.086.19a.437.437 0 01-.08-.022c-.1-.044-.187-.058-.28-.113a.77.77 0 01-.244-.238 1.177 1.177 0 01-.18-.43 2.03 2.03 0 01-.054-.513c.005-.176.031-.348.1-.512.07-.165.167-.307.29-.435a.94.94 0 01.436-.26 1.304 1.304 0 01.354-.04zm-2.953.4h.016c.142 0 .27.018.377.1a.52.52 0 01.19.266c.056.165.06.35.025.52-.037.17-.104.333-.197.478a1.177 1.177 0 01-.324.358c-.13.09-.27.135-.43.133-.16-.002-.3-.06-.42-.145a.93.93 0 01-.278-.36 1.52 1.52 0 01-.14-.533c-.01-.17.02-.34.08-.5.06-.16.155-.3.28-.413.123-.11.272-.18.433-.195a.79.79 0 01.188-.01zm5.478.196h.016c.155.005.305.054.427.14a.89.89 0 01.27.353c.06.146.08.306.068.465a1.34 1.34 0 01-.14.513 1.15 1.15 0 01-.34.378c-.138.1-.298.148-.466.144a.909.909 0 01-.435-.14 1.027 1.027 0 01-.334-.353 1.397 1.397 0 01-.166-.513 1.44 1.44 0 01.06-.517c.06-.17.16-.32.29-.44.13-.116.29-.192.466-.21a.92.92 0 01.284-.02zm-7.213.04h.02c.155.005.302.058.422.15.12.09.21.214.26.36.053.144.07.3.055.454a1.33 1.33 0 01-.148.506 1.135 1.135 0 01-.34.37c-.138.1-.297.147-.463.147a.912.912 0 01-.436-.14 1.03 1.03 0 01-.333-.35 1.397 1.397 0 01-.168-.513 1.44 1.44 0 01.062-.517c.06-.17.16-.32.29-.44.13-.116.29-.192.465-.21.09-.01.18-.01.264-.017zm8.82.166h.02c.155.004.303.055.425.145.123.09.215.213.267.36.053.145.072.3.058.455a1.34 1.34 0 01-.15.51 1.146 1.146 0 01-.342.372c-.138.1-.3.148-.466.146a.91.91 0 01-.436-.142 1.032 1.032 0 01-.333-.35 1.4 1.4 0 01-.166-.513 1.44 1.44 0 01.06-.517c.06-.17.16-.32.29-.44.13-.116.29-.192.465-.21a.9.9 0 01.268-.016zm-5.97.055c.153 0 .284.037.4.11.118.07.213.17.28.29.07.12.116.258.137.4a1.19 1.19 0 01-.04.43.94.94 0 01-.2.36.86.86 0 01-.35.247.99.99 0 01-.45.06 1.03 1.03 0 01-.425-.13 1.04 1.04 0 01-.32-.32 1.25 1.25 0 01-.16-.43c-.03-.15-.025-.3.012-.446.04-.146.11-.28.214-.393.1-.113.23-.2.38-.26a1.14 1.14 0 01.512-.018zm3.068.106c.152 0 .282.037.398.11.118.07.213.17.28.29.07.12.116.258.137.4a1.19 1.19 0 01-.04.43.94.94 0 01-.2.36.86.86 0 01-.35.247.99.99 0 01-.45.06 1.03 1.03 0 01-.425-.13 1.04 1.04 0 01-.32-.32 1.25 1.25 0 01-.16-.43c-.03-.15-.025-.3.012-.446.04-.146.11-.28.214-.393.1-.113.23-.2.38-.26a1.14 1.14 0 01.514-.018zm-7.74.05h.013c.12.003.235.037.338.1a.79.79 0 01.26.26.72.72 0 01.12.35.876.876 0 01-.05.38.754.754 0 01-.21.323.668.668 0 01-.34.185.729.729 0 01-.4-.016.714.714 0 01-.33-.228.822.822 0 01-.17-.36.92.92 0 01.02-.43c.05-.14.13-.26.24-.36.11-.098.24-.165.39-.19a.698.698 0 01.14-.014zm12.423.008h.013c.12.003.235.037.338.1a.79.79 0 01.26.26.72.72 0 01.12.35.876.876 0 01-.05.38.754.754 0 01-.21.323.668.668 0 01-.34.185.729.729 0 01-.4-.016.714.714 0 01-.33-.228.822.822 0 01-.17-.36.92.92 0 01.02-.43c.05-.14.13-.26.24-.36.11-.098.24-.165.39-.19a.698.698 0 01.14-.014z" />
    </svg>
  );
}

const platforms = [
  {
    name: "Windows",
    icon: Monitor,
    format: "Installer · .exe",
    version: "Beta 0.2 · 71 MB",
  },
  {
    name: "macOS",
    icon: Apple,
    format: "Disk Image · .dmg",
    version: "Beta 0.2 · 68 MB",
  },
  {
    name: "Linux",
    icon: LinuxIcon,
    format: "AppImage · .AppImage",
    version: "Beta 0.2 · 75 MB",
  },
];

const versions = [
  {
    version: "0.2",
    date: "2026-04-29",
    notes: "Local AI diagnostics, voice input, improved Bluetooth",
  },
  {
    version: "0.1",
    date: "2026-04-10",
    notes: "Initial beta with DTC scanning and live data",
  },
];

export default function DownloadSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".platform-card", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 65%",
          toggleActions: "play none none none",
        },
        y: 50,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-dark py-24 lg:py-32" id="download">
      <div className="max-w-[800px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center">
          <span className="text-caption text-accent-orange">DOWNLOAD</span>
          <h2 className="text-h3 text-white mt-4">Download AIscanAuto</h2>
          <p className="text-body-large text-text-muted mt-4">
            Available for Windows, macOS, and Linux — the same AI OBD2
            diagnostics experience on every platform.
          </p>
        </div>

        {/* Platform cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-16">
          {platforms.map((plat, i) => (
            <div
              key={i}
              className="platform-card bg-dark-surface rounded-2xl p-8 text-center hover:-translate-y-1 transition-all duration-200"
            >
              <plat.icon className="text-accent-blue mx-auto" size={48} />
              <h3 className="font-display text-xl font-bold text-white mt-4">
                {plat.name}
              </h3>
              <p className="text-text-muted text-xs mt-1">{plat.format}</p>
              <p className="text-text-muted text-xs mt-1">{plat.version}</p>
              <button className="bg-accent-blue text-white font-semibold px-8 py-3 rounded-full mt-6 hover:bg-accent-blue/90 transition-colors cursor-default">
                Download
              </button>
            </div>
          ))}
        </div>

        {/* Version history */}
        <div className="mt-16">
          <h3 className="font-display text-xl font-bold text-white mb-6">
            Version history
          </h3>
          <div className="border border-dark-surface rounded-xl overflow-hidden">
            <div className="grid grid-cols-3 gap-4 px-6 py-3 bg-dark-surface text-text-muted text-caption">
              <span>Version</span>
              <span>Published</span>
              <span>Notes</span>
            </div>
            {versions.map((v, i) => (
              <div
                key={i}
                className="grid grid-cols-3 gap-4 px-6 py-4 border-t border-dark-surface text-white text-sm"
              >
                <span className="font-semibold">{v.version}</span>
                <span className="text-text-muted">{v.date}</span>
                <span className="text-text-muted">{v.notes}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
