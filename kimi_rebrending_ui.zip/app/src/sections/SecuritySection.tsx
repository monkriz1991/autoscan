import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Shield, X, Minus, Globe } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

type Lang = "en" | "ru" | "de" | "es" | "pl";

const translations: Record<Lang, {
  badge: string;
  title: string;
  subtitle: string;
  competitors: string[];
  rows: { key: string; values: [string | null, string | null, string | null]; }[];
  footer: string;
}> = {
  en: {
    badge: "SECURITY",
    title: "Your data stays yours",
    subtitle: "Independent security audit compared to competitors",
    competitors: ["ai4car.app", "aiscanauto.com", "obdai.app"],
    rows: [
      { key: "Security Grade", values: ["🔴 F", "🟢 A", "🟡 D"] },
      { key: "CMS / Stack", values: ["Next.js", "nginx (custom)", "WordPress"] },
      { key: "HSTS", values: [null, "✅ + preload", null] },
      { key: "X-Frame-Options", values: [null, "✅", null] },
      { key: "CSP", values: [null, null, null] },
      { key: "CDN / WAF", values: ["Fastly", "—", "Cloudflare"] },
      { key: "Additional Risks", values: ["Stack exposed", "nginx version", "WordPress attacks"] },
    ],
    footer: "We don't collect, store, or sell your vehicle data. All diagnostics run locally on your device.",
  },
  ru: {
    badge: "БЕЗОПАСНОСТЬ",
    title: "Ваши данные принадлежат вам",
    subtitle: "Независимый аудит безопасности по сравнению с конкурентами",
    competitors: ["ai4car.app", "aiscanauto.com", "obdai.app"],
    rows: [
      { key: "Оценка", values: ["🔴 F", "🟢 A", "🟡 D"] },
      { key: "CMS / Стек", values: ["Next.js", "nginx (custom)", "WordPress"] },
      { key: "HSTS", values: [null, "✅ + preload", null] },
      { key: "X-Frame-Options", values: [null, "✅", null] },
      { key: "CSP", values: [null, null, null] },
      { key: "CDN / WAF", values: ["Fastly", "—", "Cloudflare"] },
      { key: "Доп. риски", values: ["Стек раскрыт", "nginx версия", "WordPress атаки"] },
    ],
    footer: "Мы не собираем, не храним и не продаём данные вашего автомобиля. Вся диагностика работает локально на вашем устройстве.",
  },
  de: {
    badge: "SICHERHEIT",
    title: "Ihre Daten bleiben Ihre",
    subtitle: "Unabhängige Sicherheitsprüfung im Vergleich zu Mitbewerbern",
    competitors: ["ai4car.app", "aiscanauto.com", "obdai.app"],
    rows: [
      { key: "Sicherheitsnote", values: ["🔴 F", "🟢 A", "🟡 D"] },
      { key: "CMS / Stack", values: ["Next.js", "nginx (custom)", "WordPress"] },
      { key: "HSTS", values: [null, "✅ + preload", null] },
      { key: "X-Frame-Options", values: [null, "✅", null] },
      { key: "CSP", values: [null, null, null] },
      { key: "CDN / WAF", values: ["Fastly", "—", "Cloudflare"] },
      { key: "Zusatzrisiken", values: ["Stack offengelegt", "nginx Version", "WordPress Angriffe"] },
    ],
    footer: "Wir sammeln, speichern oder verkaufen keine Fahrzeugdaten. Die gesamte Diagnose läuft lokal auf Ihrem Gerät.",
  },
  es: {
    badge: "SEGURIDAD",
    title: "Tus datos son tuyos",
    subtitle: "Auditoría de seguridad independiente comparada con la competencia",
    competitors: ["ai4car.app", "aiscanauto.com", "obdai.app"],
    rows: [
      { key: "Calificación", values: ["🔴 F", "🟢 A", "🟡 D"] },
      { key: "CMS / Stack", values: ["Next.js", "nginx (custom)", "WordPress"] },
      { key: "HSTS", values: [null, "✅ + preload", null] },
      { key: "X-Frame-Options", values: [null, "✅", null] },
      { key: "CSP", values: [null, null, null] },
      { key: "CDN / WAF", values: ["Fastly", "—", "Cloudflare"] },
      { key: "Riesgos adic.", values: ["Stack expuesto", "versión nginx", "Ataques WordPress"] },
    ],
    footer: "No recopilamos, almacenamos ni vendemos los datos de su vehículo. Todo el diagnóstico se ejecuta localmente en su dispositivo.",
  },
  pl: {
    badge: "BEZPIECZEŃSTWO",
    title: "Twoje dane pozostają Twoje",
    subtitle: "Niezależny audyt bezpieczeństwa w porównaniu z konkurencją",
    competitors: ["ai4car.app", "aiscanauto.com", "obdai.app"],
    rows: [
      { key: "Ocena", values: ["🔴 F", "🟢 A", "🟡 D"] },
      { key: "CMS / Stack", values: ["Next.js", "nginx (custom)", "WordPress"] },
      { key: "HSTS", values: [null, "✅ + preload", null] },
      { key: "X-Frame-Options", values: [null, "✅", null] },
      { key: "CSP", values: [null, null, null] },
      { key: "CDN / WAF", values: ["Fastly", "—", "Cloudflare"] },
      { key: "Dod. ryzyka", values: ["Stack ujawniony", "wersja nginx", "Ataki WordPress"] },
    ],
    footer: "Nie zbieramy, nie przechowujemy ani nie sprzedajemy danych Twojego pojazdu. Cała diagnostyka działa lokalnie na Twoim urządzeniu.",
  },
};

export default function SecuritySection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [lang, setLang] = useState<Lang>("en");
  const t = translations[lang];

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".security-animate", {
        scrollTrigger: { trigger: sectionRef.current, start: "top 70%", toggleActions: "play none none none" },
        y: 50, opacity: 0, duration: 0.8, stagger: 0.12, ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const langNames: Record<Lang, string> = { en: "EN", ru: "RU", de: "DE", es: "ES", pl: "PL" };

  const cellStyle = (val: string | null, isHighlight: boolean) => {
    if (val === null) return <X size={18} className="text-red-400/60 mx-auto" />;
    if (val === "—") return <Minus size={18} className="text-text-muted/40 mx-auto" />;
    const isCheck = val && (val.includes("✅") || val.includes("+ preload"));
    return (
      <span className={`${isCheck ? "text-emerald-400" : isHighlight ? "text-white font-semibold" : "text-text-muted"} ${isHighlight && val?.includes("A") ? "text-emerald-400 font-bold" : ""}`}>
        {val}
      </span>
    );
  };

  return (
    <section ref={sectionRef} className="bg-dark py-24 lg:py-32" id="security">
      <div className="max-w-[1000px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="security-animate text-caption text-accent-orange block">{t.badge}</span>
          <h2 className="security-animate text-h3 text-white mt-3">{t.title}</h2>
          <p className="security-animate text-text-muted mt-3 max-w-[500px] mx-auto">{t.subtitle}</p>

          {/* Language switcher */}
          <div className="security-animate flex items-center justify-center gap-2 mt-6">
            <Globe size={16} className="text-text-muted" />
            {(Object.keys(langNames) as Lang[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                className={`text-sm font-medium px-3 py-1 rounded-full transition-colors ${
                  lang === l ? "bg-accent-blue text-white" : "text-text-muted hover:text-white"
                }`}
              >
                {langNames[l]}
              </button>
            ))}
          </div>
        </div>

        {/* Security comparison table */}
        <div className="security-animate bg-dark-surface rounded-2xl border border-white/5 overflow-hidden">
          {/* Table header */}
          <div className="grid grid-cols-4 gap-0">
            <div className="p-4 border-b border-r border-white/5 text-text-muted text-sm font-medium" />
            {t.competitors.map((name, i) => (
              <div
                key={i}
                className={`p-4 border-b border-white/5 text-sm font-semibold text-center ${
                  i === 1 ? "text-accent-blue bg-accent-blue/5" : "text-text-muted"
                }`}
              >
                {name}
              </div>
            ))}
          </div>

          {/* Table rows */}
          {t.rows.map((row, i) => (
            <div key={i} className={`grid grid-cols-4 gap-0 ${i % 2 === 0 ? "bg-white/[0.02]" : ""}`}>
              <div className="p-4 border-r border-white/5 text-white/80 text-sm font-medium flex items-center">
                {row.key}
              </div>
              {row.values.map((val, j) => (
                <div
                  key={j}
                  className={`p-4 text-sm text-center flex items-center justify-center ${
                    j === 1 ? "bg-accent-blue/[0.03]" : ""
                  }`}
                >
                  {cellStyle(val, j === 1)}
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Footer note */}
        <div className="security-animate flex items-start gap-4 mt-8 bg-emerald-500/5 border border-emerald-500/10 rounded-xl p-5">
          <Shield size={22} className="text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-white/90 text-sm leading-relaxed">{t.footer}</p>
            <p className="text-text-muted text-xs mt-2">
              No subscription required for local mode. Your diagnostic data never leaves your computer.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
