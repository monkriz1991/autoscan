import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Cpu, WifiOff, Sparkles, AlertTriangle } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const highlights = [
  {
    icon: WifiOff,
    title: "100% Offline",
    desc: "No internet connection required. Your vehicle data never leaves your device.",
  },
  {
    icon: Sparkles,
    title: "Unlimited AI",
    desc: "No daily limits, no API keys, no subscription. Ask as many questions as you need.",
  },
  {
    icon: Cpu,
    title: "GGUF Models",
    desc: "Download optimized models like Gemma, Llama, or Mistral. Run them locally via built-in llama-server.",
  },
];

export default function LocalAISection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".local-ai-animate", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 70%",
          toggleActions: "play none none none",
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        stagger: 0.12,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-white py-24 lg:py-32" id="local-ai">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Screenshot */}
          <div className="local-ai-animate relative order-2 lg:order-1">
            <div className="rounded-xl overflow-hidden shadow-2xl border border-gray-200">
              <img
                src="/screenshot-local-ai.png"
                alt="AIscanAuto local AI engine settings showing local llama-server configuration with Gemma model selection"
                className="w-full h-auto"
                loading="lazy"
              />
            </div>
            {/* Floating badge */}
            <div className="absolute -bottom-3 -right-3 bg-accent-blue text-white text-xs font-bold px-4 py-2 rounded-full shadow-lg">
              gemma-4-E2B-it
            </div>
          </div>

          {/* Right: Content */}
          <div className="order-1 lg:order-2">
            <span className="local-ai-animate text-caption text-accent-orange block">
              LOCAL AI
            </span>
            <h2 className="local-ai-animate text-h3 text-dark mt-3">
              Run AI models locally — no internet, no limits, no cost
            </h2>

            {/* SEO-rich description */}
            <div className="local-ai-animate mt-6 space-y-4">
              <p className="text-dark/80 text-lg leading-relaxed">
                AIscanAuto now supports running local large language models
                directly on your computer through an integrated llama-server.
                Download any GGUF-compatible model — Gemma, Llama, Mistral, or
                others — and get unlimited AI-powered car diagnostics completely
                offline. No cloud API calls, no data sent to external servers,
                no daily quotas, and absolutely no subscription fees.
              </p>
              <p className="text-dark/80 leading-relaxed">
                This means you can analyze DTC trouble codes, get repair
                recommendations, interpret live sensor data, and generate
                diagnostic reports using AI even in areas with poor or no
                internet connectivity. Perfect for workshops, roadside
                diagnostics, or privacy-conscious users who want complete
                control over their vehicle data.
              </p>
            </div>

            {/* Highlight cards */}
            <div className="local-ai-animate grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8">
              {highlights.map((h, i) => (
                <div
                  key={i}
                  className="bg-surface-light rounded-xl p-5 hover:-translate-y-0.5 transition-all duration-200"
                >
                  <h.icon className="text-accent-blue mb-3" size={24} />
                  <h3 className="font-display text-sm font-bold text-dark">
                    {h.title}
                  </h3>
                  <p className="text-dark/60 text-sm mt-1 leading-relaxed">
                    {h.desc}
                  </p>
                </div>
              ))}
            </div>

            {/* Hardware warning */}
            <div className="local-ai-animate flex items-start gap-3 mt-8 bg-amber-50 border border-amber-200 rounded-xl p-4">
              <AlertTriangle
                size={18}
                className="text-amber-500 shrink-0 mt-0.5"
              />
              <p className="text-amber-800 text-sm leading-relaxed">
                <strong>Hardware requirements apply.</strong> Local AI models
                require sufficient RAM (8GB+ recommended) and a modern CPU. On
                low-end or older computers, model loading may be slow or
                unavailable. Cloud AI mode remains available as a fallback on
                all devices.
              </p>
            </div>

            {/* Hidden SEO keywords */}
            <div className="sr-only" aria-hidden="true">
              <p>
                offline AI car diagnostics local llm model gguf gemma llama
                mistral without internet free obd2 scanner no subscription
                unlimited AI analysis on-device AI automotive diagnostic tool
                privacy-first car diagnostic software local llama server
                edge AI vehicle diagnostics no cloud dependency offline DTC
                analysis free car repair assistant
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
