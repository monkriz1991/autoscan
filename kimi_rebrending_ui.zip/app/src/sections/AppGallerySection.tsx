import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ChevronLeft, ChevronRight, ZoomIn } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const screenshots = [
  {
    src: "/screenshot-diagnostics-ai.png",
    alt: "AIscanAuto Diagnostics & AI Assistant — showing local llama-server, GearMind AI chat, Trouble Codes DTCs panel, and AI diagnostic report section",
    caption: "Diagnostics & AI Assistant — DTC codes + GearMind AI chat",
  },
  {
    src: "/screenshot-pdf-report.png",
    alt: "AIscanAuto PDF diagnostic report showing Critical condition with fault codes P0420, P0171, P0128 marked HIGH severity",
    caption: "PDF Report — Critical condition summary with export",
  },
  {
    src: "/screenshot-local-ai.png",
    alt: "AIscanAuto AI engine settings — Local mode, llama-server configuration, Gemma model selection, local models download",
    caption: "AI Engine — Local llama-server with model selection",
  },
];

export default function AppGallerySection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const [lightbox, setLightbox] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".gallery-animate", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 70%",
          toggleActions: "play none none none",
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        stagger: 0.12,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  const next = () => setActive((a) => (a + 1) % screenshots.length);
  const prev = () => setActive((a) => (a - 1 + screenshots.length) % screenshots.length);

  return (
    <section ref={sectionRef} className="bg-surface-light py-24 lg:py-32" id="gallery">
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center mb-12">
          <span className="gallery-animate text-caption text-accent-blue block">
            APP PREVIEW
          </span>
          <h2 className="gallery-animate text-h3 text-dark mt-3">
            See what you'll get
          </h2>
          <p className="gallery-animate text-dark/60 text-lg mt-3 max-w-[500px] mx-auto">
            Real screenshots from the AIscanAuto desktop app. This is exactly
            what you'll download.
          </p>
        </div>

        {/* Main image */}
        <div className="gallery-animate relative">
          <div
            className="relative rounded-xl overflow-hidden shadow-2xl border border-gray-200 cursor-pointer group"
            onClick={() => setLightbox(true)}
          >
            <img
              src={screenshots[active].src}
              alt={screenshots[active].alt}
              className="w-full h-auto transition-opacity duration-300"
            />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
              <ZoomIn
                size={32}
                className="text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg"
              />
            </div>
          </div>

          {/* Caption */}
          <p className="text-center text-dark/50 text-sm mt-4">
            {screenshots[active].caption}
          </p>

          {/* Nav arrows */}
          <button
            onClick={prev}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 backdrop-blur rounded-full shadow-lg flex items-center justify-center text-dark hover:bg-white transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 backdrop-blur rounded-full shadow-lg flex items-center justify-center text-dark hover:bg-white transition-colors"
          >
            <ChevronRight size={20} />
          </button>
        </div>

        {/* Thumbnails */}
        <div className="gallery-animate flex items-center justify-center gap-4 mt-8">
          {screenshots.map((s, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`relative rounded-lg overflow-hidden border-2 transition-all duration-200 w-32 h-20 ${
                i === active
                  ? "border-accent-blue shadow-md"
                  : "border-transparent opacity-60 hover:opacity-100"
              }`}
            >
              <img
                src={s.src}
                alt={s.caption}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>

        {/* Dots */}
        <div className="flex items-center justify-center gap-2 mt-6">
          {screenshots.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className={`w-2 h-2 rounded-full transition-all duration-200 ${
                i === active ? "bg-accent-blue w-6" : "bg-dark/20"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-8"
          onClick={() => setLightbox(false)}
        >
          <img
            src={screenshots[active].src}
            alt={screenshots[active].alt}
            className="max-w-full max-h-full rounded-lg"
          />
          <button
            onClick={() => setLightbox(false)}
            className="absolute top-6 right-6 text-white/70 hover:text-white text-2xl"
          >
            ✕
          </button>
        </div>
      )}
    </section>
  );
}
