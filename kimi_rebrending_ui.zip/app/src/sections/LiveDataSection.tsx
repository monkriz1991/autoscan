import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

gsap.registerPlugin(ScrollTrigger);

export default function LiveDataSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".live-animate", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 65%",
          toggleActions: "play none none none",
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="bg-accent-blue py-24 lg:py-32"
      id="live-data"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left: Content */}
          <div className="live-animate">
            <span className="inline-block bg-accent-orange text-white text-caption px-3 py-1 rounded-full mb-4">
              PRO
            </span>
            <h2 className="text-h3 text-white mt-1">
              Live engine data, beautifully displayed
            </h2>
            <p className="text-body-large text-white/80 mt-5 max-w-[480px]">
              Monitor real-time engine parameters. Freeze frame data and sensor
              history graphs. Track fuel trims, oxygen sensors, coolant
              temperature, RPM, and more — all while the engine runs.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-8">
              {[
                { value: "50+", label: "PID parameters" },
                { value: "Real-time", label: "Data streaming" },
                { value: "Graphs", label: "Visual history" },
              ].map((stat, i) => (
                <div key={i}>
                  <span className="font-display text-2xl font-bold text-white">
                    {stat.value}
                  </span>
                  <p className="text-white/60 text-sm mt-1">{stat.label}</p>
                </div>
              ))}
            </div>

            <Link
              to="/pricing"
              className="inline-flex items-center gap-2 text-white hover:underline mt-8 transition-all"
            >
              <span className="text-base">Upgrade to Pro</span>
              <ArrowRight size={16} />
            </Link>
          </div>

          {/* Right: Real live data screenshot */}
          <div className="live-animate relative">
            <div className="rounded-xl overflow-hidden shadow-2xl border border-white/20">
              <img
                src="/hero-slide-live.png"
                alt="AIscanAuto live vehicle data dashboard showing RPM, vehicle speed, coolant temp, battery voltage, engine load and more"
                className="w-full h-auto"
                loading="lazy"
              />
            </div>
            {/* Annotation badges */}
            <div className="absolute top-[30%] left-[5%] bg-white/90 text-dark text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm shadow-lg">
              Engine RPM: 1350
            </div>
            <div className="absolute bottom-[25%] right-[5%] bg-white/90 text-dark text-xs font-semibold px-3 py-1.5 rounded-full backdrop-blur-sm shadow-lg">
              Coolant: 82°C
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
