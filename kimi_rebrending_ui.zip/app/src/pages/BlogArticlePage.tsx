import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Calendar, Clock, Share2, Bookmark } from "lucide-react";

const articles: Record<string, {
  title: string;
  date: string;
  readTime: string;
  category: string;
  color: string;
  content: { type: string; text?: string; items?: string[] }[];
}> = {
  "obd2-live-data-explained": {
    title: "OBD2 live data explained: PIDs, fuel trim, and what to log",
    date: "April 12, 2026",
    readTime: "8 min read",
    category: "Guide",
    color: "bg-emerald-500",
    content: [
      { type: "p", text: "Live data — also called Parameter IDs or PIDs — is the real-time stream of information your car's ECU generates while the engine runs. Unlike reading static fault codes, live data lets you see how systems behave under actual driving conditions." },
      { type: "h2", text: "What are PIDs?" },
      { type: "p", text: "PIDs (Parameter IDs) are standardized codes that represent specific sensor readings and calculated values in your vehicle. The OBD2 standard defines over 200 standard PIDs, and manufacturers can add their own proprietary ones." },
      { type: "h2", text: "Key PIDs to monitor" },
      { type: "ul", items: [
        "Fuel Trim (Short & Long Term) — shows how much the ECU is compensating for fuel mixture",
        "O2 Sensor Voltage — indicates catalytic converter efficiency",
        "MAF Rate — measures air entering the engine",
        "Coolant Temperature — essential for diagnosing overheating",
        "RPM & Engine Load — baseline for all other readings",
      ]},
      { type: "h2", text: "When to log vs. glance" },
      { type: "p", text: "For intermittent issues (like a misfire that only happens at highway speeds), logging beats snapshots. AIscanAuto Pro lets you record live data sessions and review them later with AI-powered analysis." },
    ],
  },
  "p0420-catalyst-efficiency": {
    title: "P0420 meaning: catalyst efficiency and what to check first",
    date: "March 24, 2026",
    readTime: "6 min read",
    category: "DTC Codes",
    color: "bg-orange-500",
    content: [
      { type: "p", text: "P0420 is one of the most common and often most expensive OBD2 trouble codes. It indicates that your catalytic converter is not cleaning exhaust gases as efficiently as it should. But before you replace an expensive cat, there are several cheaper things to check." },
      { type: "h2", text: "What P0420 means" },
      { type: "p", text: "The code 'Catalyst System Efficiency Below Threshold (Bank 1)' means the downstream O2 sensor is detecting a signal too similar to the upstream sensor — suggesting the catalytic converter isn't doing its job of reducing harmful emissions." },
      { type: "h2", text: "Check these first (cheaper than a cat)" },
      { type: "ul", items: [
        "Exhaust leaks before the catalytic converter — even a small leak throws off O2 readings",
        "Failing upstream or downstream O2 sensors — test with a multimeter or scan tool",
        "Rich fuel mixture — check fuel trim values; high positive trim can poison the cat",
        "Oil or coolant contamination — burning oil coats the catalyst surface",
      ]},
      { type: "h2", text: "Live data to watch" },
      { type: "p", text: "In AIscanAuto, monitor O2 sensor voltages and fuel trims. A healthy converter shows the downstream O2 sensor with relatively stable voltage, while the upstream sensor fluctuates rapidly. If both sensors mirror each other, the cat is likely failing." },
    ],
  },
};

const defaultArticle = {
  title: "Article",
  date: "2026",
  readTime: "5 min",
  category: "Blog",
  color: "bg-accent-blue",
  content: [
    { type: "p", text: "This article is coming soon. Check back for updates or browse our other guides." },
  ],
};

export default function BlogArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const article = articles[slug || ""] || defaultArticle;

  return (
    <div className="pt-24">
      {/* Header image */}
      <div className={`h-64 lg:h-80 ${article.color} relative`}>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-display text-6xl lg:text-8xl font-black text-white/20 uppercase tracking-tight">
            {article.category}
          </span>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-dark/80 to-transparent h-32" />
      </div>

      <article className="bg-white pb-20">
        <div className="max-w-[720px] mx-auto px-6 lg:px-10 -mt-20 relative z-10">
          {/* Article card */}
          <div className="bg-white rounded-2xl shadow-xl p-8 lg:p-10">
            {/* Meta */}
            <div className="flex items-center gap-3 text-text-muted text-sm mb-4">
              <span className="bg-accent-blue/10 text-accent-blue text-xs font-semibold px-3 py-1 rounded-full">
                {article.category}
              </span>
              <span className="flex items-center gap-1">
                <Calendar size={14} />
                {article.date}
              </span>
              <span className="flex items-center gap-1">
                <Clock size={14} />
                {article.readTime}
              </span>
            </div>

            <h1 className="font-display text-3xl lg:text-4xl font-bold text-dark leading-tight">
              {article.title}
            </h1>

            {/* Actions */}
            <div className="flex items-center gap-3 mt-6 pt-6 border-t border-gray-100">
              <button className="flex items-center gap-2 text-text-muted hover:text-dark text-sm transition-colors">
                <Share2 size={16} /> Share
              </button>
              <button className="flex items-center gap-2 text-text-muted hover:text-dark text-sm transition-colors">
                <Bookmark size={16} /> Save
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="mt-10 space-y-6">
            {article.content.map((block, i) => {
              if (block.type === "p") {
                return (
                  <p key={i} className="text-dark/80 text-lg leading-relaxed">
                    {block.text}
                  </p>
                );
              }
              if (block.type === "h2") {
                return (
                  <h2 key={i} className="font-display text-2xl font-bold text-dark mt-8">
                    {block.text}
                  </h2>
                );
              }
              if (block.type === "ul") {
                return (
                  <ul key={i} className="space-y-3">
                    {block.items?.map((item, j) => (
                      <li key={j} className="flex items-start gap-3 text-dark/80 text-lg">
                        <span className="w-2 h-2 rounded-full bg-accent-blue mt-2.5 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                );
              }
              return null;
            })}
          </div>

          {/* Back to blog */}
          <div className="mt-14 pt-8 border-t border-gray-100">
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 text-accent-blue hover:underline font-medium"
            >
              <ArrowLeft size={18} />
              Back to all articles
            </Link>
          </div>
        </div>
      </article>
    </div>
  );
}
