import { Check } from "lucide-react";
import { Link } from "react-router-dom";

const freeFeatures = [
  "DTC error scanning",
  "Up to 10 AI analyses/day",
  "Live PID data",
  "Readiness monitors",
  "ELM327 connection",
  "Basic freeze frame",
];

const proFeatures = [
  "Unlimited AI analyses",
  "Advanced live data graphs",
  "Freeze frame history",
  "Priority support",
  "All future updates",
  "Voice input",
  "Local AI mode (offline)",
  "Custom PID logging",
];

export default function PricingPage() {
  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-dark py-20 lg:py-28">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 text-center">
          <span className="text-caption text-accent-orange">PRICING</span>
          <h1 className="text-h2 text-white mt-4">Choose your plan</h1>
          <p className="text-body-large text-text-muted mt-6 max-w-[600px] mx-auto">
            Start free with core diagnostics. Upgrade to Pro for unlimited AI
            guidance and advanced features.
          </p>
        </div>
      </section>

      {/* Pricing cards */}
      <section className="bg-surface-light py-20 lg:py-28">
        <div className="max-w-[900px] mx-auto px-6 lg:px-10">
          <div className="flex flex-col md:flex-row items-stretch justify-center gap-8">
            {/* Free */}
            <div className="flex-1 bg-white border-2 border-dark rounded-3xl p-10 md:p-12 hover:shadow-xl transition-all duration-300">
              <h2 className="font-display text-3xl font-bold text-dark">
                Free
              </h2>
              <div className="flex items-baseline mt-4">
                <span className="font-display text-6xl font-black text-dark">
                  $0
                </span>
                <span className="text-text-muted ml-2">/ forever</span>
              </div>
              <p className="text-text-muted mt-3">
                Perfect for DIY diagnostics and occasional use.
              </p>
              <div className="border-t border-gray-200 my-6" />
              <ul className="space-y-4">
                {freeFeatures.map((f, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <Check size={20} className="text-accent-blue shrink-0" />
                    <span className="text-dark">{f}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/download"
                className="block w-full bg-dark text-white text-center font-semibold py-4 rounded-xl mt-8 hover:bg-dark/90 transition-colors"
              >
                Download Free
              </Link>
            </div>

            {/* Pro */}
            <div className="flex-1 bg-dark border-2 border-dark rounded-3xl p-10 md:p-12 relative hover:shadow-glow-orange transition-all duration-300">
              <span className="absolute -top-3 right-6 bg-accent-orange text-white text-caption px-3 py-1 rounded-full">
                POPULAR
              </span>
              <h2 className="font-display text-3xl font-bold text-white">
                Pro
              </h2>
              <div className="flex items-baseline mt-4">
                <span className="font-display text-6xl font-black text-white">
                  $9.99
                </span>
                <span className="text-text-muted ml-2">/ month</span>
              </div>
              <p className="text-text-muted mt-3">
                For serious car enthusiasts and professional shops.
              </p>
              <div className="border-t border-dark-surface my-6" />
              <ul className="space-y-4">
                {proFeatures.map((f, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <Check
                      size={20}
                      className="text-accent-orange shrink-0"
                    />
                    <span className="text-white">{f}</span>
                  </li>
                ))}
              </ul>
              <button className="block w-full bg-accent-blue text-white text-center font-semibold py-4 rounded-xl mt-8 hover:bg-accent-blue/90 transition-colors cursor-default">
                Upgrade to Pro
              </button>
            </div>
          </div>

          {/* FAQ note */}
          <div className="text-center mt-12">
            <p className="text-dark/60">
              Questions about billing?{" "}
              <Link
                to="/faq"
                className="text-accent-blue hover:underline"
              >
                Check our FAQ
              </Link>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
