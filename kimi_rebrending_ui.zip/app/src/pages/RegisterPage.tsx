import { useState } from "react";
import { Link } from "react-router-dom";
import { UserPlus, Eye, EyeOff } from "lucide-react";

export default function RegisterPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  return (
    <div className="pt-24 min-h-screen bg-dark flex items-center justify-center px-6">
      <div className="w-full max-w-[420px]">
        {/* Header */}
        <div className="text-center mb-10">
          <Link to="/" className="text-white font-semibold text-xl tracking-wide">
            AI <span className="text-accent-blue">·</span> OBD2
          </Link>
          <h1 className="font-display text-3xl font-bold text-white mt-6">
            Create account
          </h1>
          <p className="text-text-muted mt-2">
            Start your AI-powered diagnostics journey
          </p>
        </div>

        {/* Form */}
        <div className="bg-dark-surface rounded-2xl p-8 border border-white/5">
          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-white font-medium text-sm mb-2">
                  First name
                </label>
                <input
                  type="text"
                  placeholder="John"
                  className="w-full bg-dark border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
                />
              </div>
              <div>
                <label className="block text-white font-medium text-sm mb-2">
                  Last name
                </label>
                <input
                  type="text"
                  placeholder="Doe"
                  className="w-full bg-dark border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-white font-medium text-sm mb-2">
                Email
              </label>
              <input
                type="email"
                placeholder="your@email.com"
                className="w-full bg-dark border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
              />
            </div>

            <div>
              <label className="block text-white font-medium text-sm mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Create a strong password"
                  className="w-full bg-dark border border-white/10 rounded-xl px-4 py-3.5 pr-12 text-white placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted hover:text-white transition-colors"
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              <p className="text-text-muted text-xs mt-2">
                At least 8 characters with a mix of letters, numbers, and symbols.
              </p>
            </div>

            <div>
              <label className="block text-white font-medium text-sm mb-2">
                Confirm password
              </label>
              <div className="relative">
                <input
                  type={showConfirm ? "text" : "password"}
                  placeholder="Repeat your password"
                  className="w-full bg-dark border border-white/10 rounded-xl px-4 py-3.5 pr-12 text-white placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-text-muted hover:text-white transition-colors"
                >
                  {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <label className="flex items-start gap-3 text-text-muted text-sm cursor-pointer">
              <input
                type="checkbox"
                className="mt-0.5 rounded border-white/20 bg-dark text-accent-blue"
              />
              <span>
                I agree to the{" "}
                <Link to="/terms" className="text-accent-blue hover:underline">
                  Terms of Use
                </Link>{" "}
                and{" "}
                <Link
                  to="/privacy"
                  className="text-accent-blue hover:underline"
                >
                  Privacy Policy
                </Link>
              </span>
            </label>

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-accent-blue text-white font-semibold py-4 rounded-xl hover:bg-accent-blue/90 transition-colors"
            >
              <UserPlus size={18} />
              Create Account
            </button>
          </form>

          {/* Divider */}
          <div className="flex items-center gap-4 my-6">
            <div className="flex-1 h-px bg-white/10" />
            <span className="text-text-muted text-sm">or</span>
            <div className="flex-1 h-px bg-white/10" />
          </div>

          {/* Google OAuth */}
          <button className="w-full flex items-center justify-center gap-3 bg-dark border border-white/10 text-white font-medium py-3.5 rounded-xl hover:bg-white/5 transition-colors">
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path
                fill="#4285F4"
                d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.874 2.684-6.616z"
              />
              <path
                fill="#34A853"
                d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.58-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z"
              />
              <path
                fill="#FBBC05"
                d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"
              />
              <path
                fill="#EA4335"
                d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.162 6.656 3.58 9 3.58z"
              />
            </svg>
            Sign up with Google
          </button>
        </div>

        {/* Login link */}
        <p className="text-center text-text-muted mt-8">
          Already have an account?{" "}
          <Link
            to="/login"
            className="text-accent-blue hover:underline font-medium"
          >
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
