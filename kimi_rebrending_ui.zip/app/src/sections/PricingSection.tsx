import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Check } from "lucide-react";
import { Link } from "react-router-dom";

gsap.registerPlugin(ScrollTrigger);

const freeFeatures = [
  "DTC error scanning",
  "Up to 10 AI analyses/day",
  "Live PID data",
  "Readiness monitors",
];

const proFeatures = [
  "Unlimited AI analyses",
  "Advanced live data graphs",
  "Freeze frame history",
  "Priority support",
  "All future updates",
];

export default function PricingSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".pricing-card", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 65%",
          toggleActions: "play none none none",
        },
        y: 60,
        opacity: 0,
        duration: 0.8,
        stagger: 0.2,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="bg-surface-light py-24 lg:py-32"
      id="pricing"
    >
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center">
          <span className="text-caption text-accent-blue">PRICING</span>
          <h2 className="text-h3 text-dark mt-4">
            Simple, honest pricing
          </h2>
          <p className="text-dark/80 text-lg mt-4">
            Start free. Upgrade when you need more.
          </p>
        </div>

        {/* Pricing cards */}
        <div className="flex flex-col md:flex-row items-stretch justify-center gap-8 mt-16 max-w-[800px] mx-auto">
          {/* Free card */}
          <div className="pricing-card flex-1 bg-white border-2 border-dark rounded-3xl p-10 md:p-12 hover:shadow-xl transition-all duration-300">
            <h3 className="font-display text-3xl font-bold text-dark">Free</h3>
            <div className="flex items-baseline mt-4">
              <span className="font-display text-6xl font-black text-dark">
                $0
              </span>
              <span className="text-text-muted ml-2">/ forever</span>
            </div>
            <div className="border-t border-gray-200 my-6" />
            <ul className="space-y-4">
              {freeFeatures.map((feature, i) => (
                <li key={i} className="flex items-center gap-3">
                  <Check size={20} className="text-accent-blue shrink-0" />
                  <span className="text-dark">{feature}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/download"
              className="block w-full bg-dark text-white text-center font-semibold py-4 rounded-xl mt-8 hover:bg-dark/90 transition-colors"
            >
              Download Free
            </Link>
          </div>

          {/* Pro card */}
          <div className="pricing-card flex-1 bg-dark border-2 border-dark rounded-3xl p-10 md:p-12 relative hover:shadow-glow-orange transition-all duration-300">
            {/* Popular badge */}
            <span className="absolute -top-3 right-6 bg-accent-orange text-white text-caption px-3 py-1 rounded-full">
              POPULAR
            </span>
            <h3 className="font-display text-3xl font-bold text-white">Pro</h3>
            <div className="flex items-baseline mt-4">
              <span className="font-display text-6xl font-black text-white">
                $9.99
              </span>
              <span className="text-text-muted ml-2">/ month</span>
            </div>
            <div className="border-t border-dark-surface my-6" />
            <ul className="space-y-4">
              {proFeatures.map((feature, i) => (
                <li key={i} className="flex items-center gap-3">
                  <Check size={20} className="text-accent-orange shrink-0" />
                  <span className="text-white">{feature}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/pricing"
              className="block w-full bg-accent-blue text-white text-center font-semibold py-4 rounded-xl mt-8 hover:bg-accent-blue/90 transition-colors"
            >
              Upgrade to Pro
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
