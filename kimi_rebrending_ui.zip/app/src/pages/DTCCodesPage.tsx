import { useState } from "react";
import { Search, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const dtcCodes = [
  { code: "P0420", desc: "Catalyst System Efficiency Below Threshold", category: "Powertrain" },
  { code: "P0430", desc: "Catalyst System Efficiency Below Threshold (Bank 2)", category: "Powertrain" },
  { code: "P0300", desc: "Random/Multiple Cylinder Misfire Detected", category: "Powertrain" },
  { code: "P0171", desc: "System Too Lean (Bank 1)", category: "Powertrain" },
  { code: "P0172", desc: "System Too Rich (Bank 1)", category: "Powertrain" },
  { code: "P0442", desc: "EVAP System Small Leak Detected", category: "Powertrain" },
  { code: "P0455", desc: "EVAP System Large Leak Detected", category: "Powertrain" },
  { code: "P0128", desc: "Coolant Thermostat Temperature Below Regulating Temperature", category: "Powertrain" },
  { code: "P0301", desc: "Cylinder 1 Misfire Detected", category: "Powertrain" },
  { code: "P0135", desc: "O2 Sensor Heater Circuit (Bank 1, Sensor 1)", category: "Powertrain" },
  { code: "P0440", desc: "EVAP System Malfunction", category: "Powertrain" },
  { code: "P0401", desc: "Exhaust Gas Recirculation (EGR) Flow Insufficient", category: "Powertrain" },
  { code: "P0325", desc: "Knock Sensor 1 Circuit Malfunction (Bank 1)", category: "Powertrain" },
  { code: "P0101", desc: "Mass Air Flow (MAF) Circuit Range/Performance", category: "Powertrain" },
  { code: "P0113", desc: "Intake Air Temperature (IAT) Circuit High Input", category: "Powertrain" },
  { code: "P0133", desc: "O2 Sensor Slow Response (Bank 1, Sensor 1)", category: "Powertrain" },
  { code: "P0141", desc: "O2 Sensor Heater Circuit (Bank 1, Sensor 2)", category: "Powertrain" },
  { code: "P0174", desc: "System Too Lean (Bank 2)", category: "Powertrain" },
  { code: "P0320", desc: "Ignition/Distributor Engine Speed Input Circuit", category: "Powertrain" },
  { code: "P0411", desc: "Secondary Air Injection System Incorrect Flow", category: "Powertrain" },
  { code: "P0068", desc: "MAP/MAF - Throttle Position Correlation", category: "Powertrain" },
  { code: "P1409", desc: "IAT - B Circuit Malfunction / EGR Closed Position", category: "Powertrain" },
  { code: "U0314", desc: "Software Incompatibility with Four-Wheel Drive", category: "Network" },
];

export default function DTCCodesPage() {
  const [search, setSearch] = useState("");

  const filtered = dtcCodes.filter(
    (d) =>
      d.code.toLowerCase().includes(search.toLowerCase()) ||
      d.desc.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-dark py-20 lg:py-28">
        <div className="max-w-[1000px] mx-auto px-6 lg:px-10">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-text-muted hover:text-white transition-colors mb-6"
          >
            <ArrowLeft size={18} />
            Back to home
          </Link>
          <span className="text-caption text-accent-orange block mb-4">
            DTC CODES
          </span>
          <h1 className="text-h2 text-white">OBD2 Fault Code Library</h1>
          <p className="text-body-large text-text-muted mt-6 max-w-[600px]">
            Search thousands of powertrain, body, chassis, and network
            diagnostic trouble codes — definitions, typical causes, and next
            steps.
          </p>

          {/* Search */}
          <div className="relative mt-10 max-w-[500px]">
            <Search
              className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted"
              size={20}
            />
            <input
              type="text"
              placeholder="Search codes (e.g. P0420) or descriptions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-dark-surface border border-white/10 rounded-xl pl-12 pr-4 py-4 text-white placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
            />
          </div>
        </div>
      </section>

      {/* Codes grid */}
      <section className="bg-white py-20 lg:py-28">
        <div className="max-w-[1000px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map((dtc, i) => (
              <Link
                key={i}
                to={`/dtc-codes/${dtc.code}`}
                className="bg-surface-light rounded-xl p-6 hover:-translate-y-0.5 transition-all duration-200 hover:shadow-md group"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-display text-2xl font-bold text-dark group-hover:text-accent-blue transition-colors">
                    {dtc.code}
                  </span>
                  <span className="text-caption text-text-muted text-[10px]">
                    {dtc.category}
                  </span>
                </div>
                <p className="text-dark/70 text-sm leading-relaxed">
                  {dtc.desc}
                </p>
              </Link>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-20">
              <p className="text-dark/50 text-lg">
                No codes found matching "{search}"
              </p>
              <button
                onClick={() => setSearch("")}
                className="text-accent-blue mt-2 hover:underline"
              >
                Clear search
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
