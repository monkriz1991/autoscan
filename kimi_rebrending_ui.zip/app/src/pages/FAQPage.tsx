import { useState } from "react";
import { ChevronDown, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const faqs = [
  {
    question: "What is an OBD2 port and where is it located?",
    answer:
      "The OBD-II (On-Board Diagnostics) port is a standardized connection point in your vehicle for reading diagnostic data. In most cars, it's located under the dashboard on the driver's side, near the steering column. All petrol and diesel cars sold in the US since 1996 have this port.",
  },
  {
    question: "Do I need any special hardware?",
    answer:
      "You need an ELM327-compatible adapter (USB, Bluetooth, or Wi-Fi). These cost between $10-$30 and are widely available online. AIscanAuto works with any standard ELM327 adapter.",
  },
  {
    question: "Is AIscanAuto really free?",
    answer:
      "Yes, the core features — DTC scanning, live data, and up to 10 AI analyses per day — are completely free. The Pro subscription unlocks unlimited AI analyses, advanced graphs, and freeze frame history.",
  },
  {
    question: "What platforms are supported?",
    answer:
      "AIscanAuto runs on Windows 10+, macOS 12+, and Ubuntu 20.04+. Download the appropriate installer from our download page.",
  },
  {
    question: "Can AIscanAuto clear my check engine light?",
    answer:
      "Yes, the app can read and clear DTC codes, which will turn off the check engine light. However, if the underlying issue persists, the light will return.",
  },
  {
    question: "Is my data kept private?",
    answer:
      "Absolutely. All diagnostic data stays on your device. Our local AI mode works entirely offline — no data is sent to any server.",
  },
  {
    question: "How does the AI assistant work?",
    answer:
      "Our AI analyzes your vehicle's diagnostic data and provides plain-language explanations of fault codes, suggests likely causes, and recommends next steps for repair. The Pro plan includes unlimited AI queries.",
  },
  {
    question: "Can I use AIscanAuto on multiple devices?",
    answer:
      "Yes, you can install AIscanAuto on any number of devices. Your Pro subscription syncs across devices when you sign in with the same account.",
  },
];

function FAQItem({
  question,
  answer,
  isOpen,
  onClick,
}: {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}) {
  return (
    <div className="border-b border-gray-200">
      <button
        onClick={onClick}
        className="w-full flex items-center justify-between py-6 text-left group"
      >
        <span className="text-dark font-semibold text-lg pr-8 group-hover:text-accent-blue transition-colors">
          {question}
        </span>
        <ChevronDown
          size={20}
          className={`text-dark shrink-0 transition-transform duration-300 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>
      <div
        className="overflow-hidden transition-all duration-300 ease-out"
        style={{
          maxHeight: isOpen ? "300px" : "0",
          opacity: isOpen ? 1 : 0,
        }}
      >
        <p className="text-dark/80 pb-6 max-w-[640px] leading-relaxed">
          {answer}
        </p>
      </div>
    </div>
  );
}

export default function FAQPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-dark py-20 lg:py-28">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10 text-center">
          <span className="text-caption text-accent-orange">FAQ</span>
          <h1 className="text-h2 text-white mt-4">Frequently Asked Questions</h1>
          <p className="text-body-large text-text-muted mt-6">
            Answers about AIscanAuto, OBD diagnostics, AI features, billing and
            devices.
          </p>
        </div>
      </section>

      {/* FAQ list */}
      <section className="bg-white py-20 lg:py-28">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10">
          {faqs.map((faq, i) => (
            <FAQItem
              key={i}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === i}
              onClick={() => setOpenIndex(openIndex === i ? null : i)}
            />
          ))}

          {/* CTA */}
          <div className="mt-16 text-center bg-surface-light rounded-2xl p-10">
            <h3 className="font-display text-xl font-bold text-dark">
              Still have questions?
            </h3>
            <p className="text-dark/70 mt-3">
              We're here to help. Reach out to our support team.
            </p>
            <Link
              to="/contacts"
              className="inline-flex items-center gap-2 bg-accent-blue text-white font-semibold px-8 py-3 rounded-full mt-6 hover:bg-accent-blue/90 transition-colors"
            >
              Contact Support
              <ArrowRight size={18} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
