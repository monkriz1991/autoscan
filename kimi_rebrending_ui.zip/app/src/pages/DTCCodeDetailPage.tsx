import { useParams, Link } from "react-router-dom";
import { ArrowLeft, AlertTriangle, Wrench, Gauge, BookOpen } from "lucide-react";

const dtcDatabase: Record<string, {
  code: string;
  desc: string;
  category: string;
  severity: "high" | "medium" | "low";
  meaning: string;
  causes: string[];
  symptoms: string[];
  diagnostics: string[];
  relatedCodes: string[];
}> = {
  P0420: {
    code: "P0420",
    desc: "Catalyst System Efficiency Below Threshold",
    category: "Powertrain",
    severity: "high",
    meaning:
      "The ECM has detected that the catalytic converter on Bank 1 is not operating efficiently. The downstream O2 sensor readings are too similar to the upstream sensor, indicating the catalyst isn't properly reducing emissions.",
    causes: [
      "Failed or deteriorating catalytic converter",
      "Exhaust leak before or near the catalytic converter",
      "Faulty upstream or downstream O2 sensor",
      "Rich fuel mixture causing catalyst poisoning",
      "Engine misfires allowing raw fuel into the exhaust",
      "Oil or coolant contamination of the catalyst",
    ],
    symptoms: [
      "Check Engine Light illuminated",
      "Slightly reduced fuel economy",
      "Possible sulfur or rotten egg smell from exhaust",
      "Failed emissions test",
    ],
    diagnostics: [
      "Check O2 sensor waveforms with live data — upstream should fluctuate, downstream should be stable",
      "Inspect exhaust system for leaks",
      "Check fuel trim values for rich running condition",
      "Perform catalytic converter temperature test",
    ],
    relatedCodes: ["P0430", "P0171", "P0172", "P0300", "P0135"],
  },
  P0171: {
    code: "P0171",
    desc: "System Too Lean (Bank 1)",
    category: "Powertrain",
    severity: "medium",
    meaning:
      "The engine is receiving too much air or not enough fuel in Bank 1. The ECM has reached the limit of its ability to compensate by adding fuel (positive fuel trim).",
    causes: [
      "Vacuum leak in intake manifold or hoses",
      "Dirty or faulty MAF sensor",
      "Clogged fuel injectors",
      "Weak fuel pump or restricted fuel filter",
      "Exhaust leak before O2 sensor",
    ],
    symptoms: [
      "Check Engine Light",
      "Rough idle or stalling",
      "Hesitation during acceleration",
      "Reduced power",
    ],
    diagnostics: [
      "Check short and long term fuel trim with live data",
      "Smoke test for vacuum leaks",
      "Clean or test MAF sensor",
      "Check fuel pressure at the rail",
    ],
    relatedCodes: ["P0174", "P0101", "P0300", "P0420"],
  },
};

const defaultDTC = {
  code: "DTC",
  desc: "Diagnostic Trouble Code",
  category: "Powertrain",
  severity: "medium" as const,
  meaning:
    "Detailed information for this code is being compiled. Check related codes or contact support.",
  causes: ["Information coming soon"],
  symptoms: ["Information coming soon"],
  diagnostics: ["Information coming soon"],
  relatedCodes: [] as string[],
};

export default function DTCCodeDetailPage() {
  const { code } = useParams<{ code: string }>();
  const dtc = dtcDatabase[code || ""] || { ...defaultDTC, code: code || "DTC" };

  const severityColor = {
    high: "bg-red-500",
    medium: "bg-amber-500",
    low: "bg-emerald-500",
  };

  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-dark py-16 lg:py-20">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10">
          <Link
            to="/dtc-codes"
            className="inline-flex items-center gap-2 text-text-muted hover:text-white transition-colors mb-6"
          >
            <ArrowLeft size={18} />
            All DTC codes
          </Link>

          <div className="flex items-center gap-4 mb-4">
            <span className="font-display text-5xl lg:text-6xl font-black text-white">
              {dtc.code}
            </span>
            <span
              className={`${severityColor[dtc.severity]} text-white text-xs font-bold px-3 py-1 rounded-full uppercase`}
            >
              {dtc.severity} severity
            </span>
          </div>
          <p className="text-body-large text-text-muted">{dtc.desc}</p>
          <span className="text-caption text-white/40 mt-2 block">
            {dtc.category}
          </span>
        </div>
      </section>

      {/* Content */}
      <section className="bg-white py-16 lg:py-20">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10 space-y-10">
          {/* Meaning */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <BookOpen size={20} className="text-accent-blue" />
              <h2 className="font-display text-xl font-bold text-dark">
                What it means
              </h2>
            </div>
            <p className="text-dark/80 leading-relaxed">{dtc.meaning}</p>
          </div>

          {/* Symptoms */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle size={20} className="text-accent-orange" />
              <h2 className="font-display text-xl font-bold text-dark">
                Common symptoms
              </h2>
            </div>
            <ul className="space-y-2">
              {dtc.symptoms.map((s, i) => (
                <li key={i} className="flex items-start gap-3 text-dark/80">
                  <span className="w-2 h-2 rounded-full bg-accent-orange mt-2 shrink-0" />
                  {s}
                </li>
              ))}
            </ul>
          </div>

          {/* Causes */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Wrench size={20} className="text-accent-blue" />
              <h2 className="font-display text-xl font-bold text-dark">
                Likely causes
              </h2>
            </div>
            <ul className="space-y-2">
              {dtc.causes.map((c, i) => (
                <li key={i} className="flex items-start gap-3 text-dark/80">
                  <span className="w-2 h-2 rounded-full bg-accent-blue mt-2 shrink-0" />
                  {c}
                </li>
              ))}
            </ul>
          </div>

          {/* Diagnostics */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Gauge size={20} className="text-accent-blue" />
              <h2 className="font-display text-xl font-bold text-dark">
                How to diagnose
              </h2>
            </div>
            <ul className="space-y-2">
              {dtc.diagnostics.map((d, i) => (
                <li key={i} className="flex items-start gap-3 text-dark/80">
                  <span className="w-6 h-6 rounded-full bg-accent-blue/10 text-accent-blue text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  {d}
                </li>
              ))}
            </ul>
          </div>

          {/* Related codes */}
          {dtc.relatedCodes.length > 0 && (
            <div className="pt-6 border-t border-gray-100">
              <h3 className="font-display text-lg font-bold text-dark mb-4">
                Related codes
              </h3>
              <div className="flex flex-wrap gap-3">
                {dtc.relatedCodes.map((rc, i) => (
                  <Link
                    key={i}
                    to={`/dtc-codes/${rc}`}
                    className="bg-surface-light text-dark font-semibold px-5 py-2.5 rounded-xl hover:bg-accent-blue hover:text-white transition-colors"
                  >
                    {rc}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
