import { Outlet, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import Navigation from "./Navigation";
import Footer from "./Footer";

export default function Layout() {
  const { pathname } = useLocation();
  const [navSolid, setNavSolid] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setNavSolid(window.scrollY > window.innerHeight * 0.8);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-dark">
      <Navigation navSolid={navSolid} />
      <main>
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
