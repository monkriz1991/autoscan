import { useState, useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ChevronDown } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    question: "What is an OBD2 port and where is it located?",
    answer:
      "The OBD-II (On-Board Diagnostics) port is a standardized connection point in your vehicle for reading diagnostic data. In most cars, it's located under the dashboard on the driver's side, near the steering column. All petrol and diesel cars sold in the US since 1996 have this port.",
  },
  {
    question: "Do I need any special hardware?",
    answer:
      "You need an ELM327-compatible adapter (USB, Bluetooth, or Wi-Fi). These cost between $10-$30 and are widely available online. AIscanAuto works with any standard ELM327 adapter.",
  },
  {
    question: "Is AIscanAuto really free?",
    answer:
      "Yes, the core features — DTC scanning, live data, and up to 10 AI analyses per day — are completely free. The Pro subscription unlocks unlimited AI analyses, advanced graphs, and freeze frame history.",
  },
  {
    question: "What platforms are supported?",
    answer:
      "AIscanAuto runs on Windows 10+, macOS 12+, and Ubuntu 20.04+. Download the appropriate installer from our download page.",
  },
  {
    question: "Can AIscanAuto clear my check engine light?",
    answer:
      "Yes, the app can read and clear DTC codes, which will turn off the check engine light. However, if the underlying issue persists, the light will return.",
  },
  {
    question: "Is my data kept private?",
    answer:
      "Absolutely. All diagnostic data stays on your device. Our local AI mode works entirely offline — no data is sent to any server.",
  },
];

function FAQItem({
  question,
  answer,
  isOpen,
  onClick,
}: {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
}) {
  return (
    <div className="border-b border-gray-200">
      <button
        onClick={onClick}
        className="w-full flex items-center justify-between py-6 text-left group"
      >
        <span className="text-dark font-semibold text-lg pr-8 group-hover:text-accent-blue transition-colors">
          {question}
        </span>
        <ChevronDown
          size={20}
          className={`text-dark shrink-0 transition-transform duration-300 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>
      <div
        className="overflow-hidden transition-all duration-300 ease-out"
        style={{
          maxHeight: isOpen ? "300px" : "0",
          opacity: isOpen ? 1 : 0,
        }}
      >
        <p className="text-dark/80 pb-6 max-w-[640px] leading-relaxed">
          {answer}
        </p>
      </div>
    </div>
  );
}

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".faq-item", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 65%",
          toggleActions: "play none none none",
        },
        y: 30,
        opacity: 0,
        duration: 0.5,
        stagger: 0.08,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-white py-24 lg:py-32" id="faq">
      <div className="max-w-[800px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center">
          <span className="text-caption text-accent-blue">FAQ</span>
          <h2 className="text-h3 text-dark mt-4">
            Frequently asked questions
          </h2>
          <p className="text-dark/80 text-lg mt-4">
            Answers about AIscanAuto, OBD diagnostics, AI features, billing and
            devices.
          </p>
        </div>

        {/* Accordion */}
        <div className="mt-16">
          {faqs.map((faq, i) => (
            <div key={i} className="faq-item">
              <FAQItem
                question={faq.question}
                answer={faq.answer}
                isOpen={openIndex === i}
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
