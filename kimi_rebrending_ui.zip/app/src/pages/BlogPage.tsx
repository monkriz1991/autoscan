import { Link } from "react-router-dom";
import { Calendar, ArrowRight, Clock } from "lucide-react";

const blogPosts = [
  {
    title: "OBD2 live data explained: PIDs, fuel trim, and what to log",
    excerpt:
      "How to read fuel trim, O2, and MAF live PIDs — and when logging beats a one-time snapshot.",
    date: "April 12, 2026",
    category: "Guide",
    readTime: "8 min",
    slug: "obd2-live-data-explained",
    color: "bg-emerald-500",
  },
  {
    title: "OBD2 PID Reference",
    excerpt:
      "Complete reference table of common OBD2 Parameter IDs with descriptions, units, and typical value ranges.",
    date: "April 10, 2026",
    category: "Reference",
    readTime: "12 min",
    slug: "obd2-pid-reference",
    color: "bg-blue-500",
  },
  {
    title: "Choice Of OBD Scanner",
    excerpt:
      "What to look for when choosing an OBD2 scanner — hardware, software, and connectivity options compared.",
    date: "April 9, 2026",
    category: "Guide",
    readTime: "6 min",
    slug: "choice-of-obd-scanner",
    color: "bg-amber-500",
  },
  {
    title: "Used car inspection with OBD2: pre-purchase checklist",
    excerpt:
      "What to scan, which monitors matter, and how pending codes help you negotiate a fair price.",
    date: "April 6, 2026",
    category: "Guide",
    readTime: "10 min",
    slug: "used-car-inspection-obd2",
    color: "bg-rose-500",
  },
  {
    title: "Car shaking when idle: rough idle causes and OBD2 diagnosis",
    excerpt:
      "Why idle feels rough, which DTCs and PIDs to watch, and how to separate misfire from mounts or fuel issues.",
    date: "April 3, 2026",
    category: "Diagnostics",
    readTime: "7 min",
    slug: "rough-idle-obd2-diagnosis",
    color: "bg-violet-500",
  },
  {
    title: "How to use ELM327: OBD2 adapter setup and connection guide",
    excerpt:
      "ELM327 pairing, Bluetooth vs USB vs Wi-Fi, and first checks after you connect an OBD2 adapter.",
    date: "March 31, 2026",
    category: "Guide",
    readTime: "5 min",
    slug: "how-to-use-elm327",
    color: "bg-sky-500",
  },
  {
    title: "Choosing an OBD2 app in 2026: live data, AI, and fair comparison",
    excerpt:
      "Criteria for the best OBD2 scanner apps: platforms, PIDs, AI guidance, pricing — plus a detailed comparison.",
    date: "March 27, 2026",
    category: "Review",
    readTime: "9 min",
    slug: "choosing-obd2-app-2026",
    color: "bg-teal-500",
  },
  {
    title: "P0420 meaning: catalyst efficiency and what to check first",
    excerpt:
      "What P0420 means, common causes beyond the catalytic converter, and how live OBD2 data guides diagnosis.",
    date: "March 24, 2026",
    category: "DTC Codes",
    readTime: "6 min",
    slug: "p0420-catalyst-efficiency",
    color: "bg-orange-500",
  },
];

export default function BlogPage() {
  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-dark py-20 lg:py-28">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 text-center">
          <span className="text-caption text-accent-orange">BLOG</span>
          <h1 className="text-h2 text-white mt-4">Guides &amp; Insights</h1>
          <p className="text-body-large text-text-muted mt-6 max-w-[600px] mx-auto">
            Guides on OBD2 error codes, ELM327 setup, live data PIDs, used-car
            checks, and AIscanAuto updates.
          </p>
        </div>
      </section>

      {/* Blog posts grid */}
      <section className="bg-white py-20 lg:py-28">
        <div className="max-w-[1100px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {blogPosts.map((post, i) => (
              <Link
                key={i}
                to={`/blog/${post.slug}`}
                className="group bg-surface-light rounded-2xl overflow-hidden hover:-translate-y-1 transition-all duration-300 hover:shadow-lg flex flex-col"
              >
                {/* Article image placeholder */}
                <div className={`h-40 ${post.color} relative overflow-hidden`}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="font-display text-4xl font-black text-white/30 uppercase tracking-tight">
                      {post.category}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-4">
                    <span className="bg-white/90 text-dark text-xs font-semibold px-3 py-1 rounded-full">
                      {post.category}
                    </span>
                  </div>
                </div>

                <div className="p-7 flex-1 flex flex-col">
                  <div className="flex items-center gap-3 text-text-muted text-sm mb-3">
                    <span className="flex items-center gap-1">
                      <Calendar size={14} />
                      {post.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={14} />
                      {post.readTime}
                    </span>
                  </div>
                  <h2 className="font-display text-xl font-bold text-dark group-hover:text-accent-blue transition-colors leading-tight">
                    {post.title}
                  </h2>
                  <p className="text-dark/60 mt-3 leading-relaxed text-[15px] flex-1">
                    {post.excerpt}
                  </p>
                  <div className="mt-5 pt-4 border-t border-gray-100">
                    <span className="inline-flex items-center gap-1 text-accent-blue text-sm font-medium group-hover:underline">
                      Read article
                      <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
