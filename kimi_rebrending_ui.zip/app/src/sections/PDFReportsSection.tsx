import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { FileText, Download, Paintbrush, Check } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const freeFeatures = [
  "Generate structured PDF diagnostic reports",
  "List all active and pending DTC codes",
  "Include AI analysis summary",
  "Download and save locally",
];

const proFeatures = [
  "Everything in Free, plus:",
  "Custom logo & brand colors on reports",
  "Business name and contact details",
  "Professional layout for customer handover",
];

export default function PDFReportsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".pdf-animate", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 70%",
          toggleActions: "play none none none",
        },
        y: 50,
        opacity: 0,
        duration: 0.8,
        stagger: 0.12,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-dark py-24 lg:py-32" id="pdf-reports">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Content */}
          <div>
            <span className="pdf-animate text-caption text-accent-orange block">
              PDF REPORTS
            </span>
            <h2 className="pdf-animate text-h3 text-white mt-3">
              Professional diagnostic reports in one click
            </h2>
            <p className="pdf-animate text-body-large text-text-muted mt-5 max-w-[480px]">
              Scan your vehicle, generate a comprehensive PDF report with all
              fault codes, severity levels, and AI-powered analysis — ready to
              share with your mechanic or customer.
            </p>

            {/* Free tier */}
            <div className="pdf-animate mt-8">
              <h3 className="flex items-center gap-2 text-white font-semibold text-lg">
                <FileText size={20} className="text-accent-blue" />
                Free reports
              </h3>
              <ul className="mt-3 space-y-2">
                {freeFeatures.map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-text-muted text-[15px]">
                    <Check size={16} className="text-accent-blue shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            {/* Pro tier */}
            <div className="pdf-animate mt-8 pt-6 border-t border-white/10">
              <h3 className="flex items-center gap-2 text-white font-semibold text-lg">
                <Paintbrush size={20} className="text-accent-orange" />
                Branded reports — Pro plan
              </h3>
              <ul className="mt-3 space-y-2">
                {proFeatures.map((f, i) => (
                  <li key={i} className="flex items-center gap-3 text-text-muted text-[15px]">
                    <Check size={16} className="text-accent-orange shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            {/* Hidden SEO */}
            <div className="sr-only" aria-hidden="true">
              <p>
                PDF diagnostic report car OBD2 scanner branded report auto
                repair shop white label custom logo vehicle health report DTC
                code report generator automotive PDF export mechanic report
                customer handover professional car diagnostic document
              </p>
            </div>
          </div>

          {/* Right: Screenshot */}
          <div className="pdf-animate relative">
            <div className="rounded-xl overflow-hidden shadow-2xl border border-white/10">
              <img
                src="/screenshot-pdf-report.png"
                alt="AIscanAuto PDF diagnostic report showing Critical condition banner with fault codes P0420, P0171, P0128 and Open reports folder button"
                className="w-full h-auto"
                loading="lazy"
              />
            </div>
            {/* Floating stats */}
            <div className="absolute -bottom-4 -left-4 bg-accent-orange text-white text-sm font-bold px-5 py-2.5 rounded-full shadow-lg flex items-center gap-2">
              <Download size={16} />
              PDF Export
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
