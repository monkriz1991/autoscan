import SEOKeywords from "../components/SEOKeywords";
import HeroSection from "../sections/HeroSection";
import FeaturesSection from "../sections/FeaturesSection";
import AppGallerySection from "../sections/AppGallerySection";
import InterfaceSection from "../sections/InterfaceSection";
import LiveDataSection from "../sections/LiveDataSection";
import LocalAISection from "../sections/LocalAISection";
import PDFReportsSection from "../sections/PDFReportsSection";
import SecuritySection from "../sections/SecuritySection";
import CompatibilitySection from "../sections/CompatibilitySection";
import DTCSection from "../sections/DTCSection";
import PricingSection from "../sections/PricingSection";
import DownloadSection from "../sections/DownloadSection";
import FAQSection from "../sections/FAQSection";

export default function HomePage() {
  return (
    <>
      <SEOKeywords />
      <HeroSection />
      <FeaturesSection />
      <AppGallerySection />
      <InterfaceSection />
      <LiveDataSection />
      <LocalAISection />
      <PDFReportsSection />
      <SecuritySection />
      <CompatibilitySection />
      <DTCSection />
      <PricingSection />
      <DownloadSection />
      <FAQSection />
    </>
  );
}
