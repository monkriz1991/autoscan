export default function PrivacyPage() {
  return (
    <div className="pt-24">
      <section className="bg-dark py-20 lg:py-28">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10">
          <span className="text-caption text-accent-orange">LEGAL</span>
          <h1 className="text-h2 text-white mt-4">Privacy Policy</h1>
          <p className="text-text-muted mt-4">Last updated: May 1, 2026</p>
        </div>
      </section>

      <section className="bg-white py-20 lg:py-28">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10 space-y-8 text-dark/80 leading-relaxed">
          <p>
            This Policy explains how AIscanAuto processes personal data when you
            use our website and related services. For operational contact
            details, see the Contacts page.
          </p>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              1. General provisions
            </h2>
            <p>
              This Privacy Policy applies to all information that the website
              https://aiscanauto.com may obtain about users during their use of
              the Website. By using the Website, the User fully and
              unconditionally agrees to the terms of this Policy.
            </p>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              2. Types of data processed
            </h2>
            <p>The Website may process the following categories of User data:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>
                Data voluntarily provided by the User via Website forms (name,
                phone number, e-mail, and any other information the User chooses
                to provide);
              </li>
              <li>
                Data automatically transmitted in the course of using the
                Website: IP address, cookie data, browser and device
                information, access time, referrer information, statistics of
                visits and actions on the Website;
              </li>
              <li>
                Anonymized statistical data collected through web analytics
                services.
              </li>
            </ul>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              3. Purposes of personal data processing
            </h2>
            <p>
              The User's personal data may be processed by the Controller for
              the following purposes:
            </p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Providing access to the functionality of the Website;</li>
              <li>Processing User requests and inquiries;</li>
              <li>
                Concluding and performing contracts, transactions, and other
                agreements with the User;
              </li>
              <li>
                Sending informational notifications related to the use of the
                Website;
              </li>
              <li>
                Sending (where required, subject to User consent) advertising and
                marketing materials;
              </li>
              <li>
                Improving the quality of the Website, user experience, and
                developing new services and features;
              </li>
              <li>Complying with applicable legal requirements.</li>
            </ul>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              4. Data disclosure and storage
            </h2>
            <p>
              The Controller may disclose the User's personal data to third
              parties when such disclosure is necessary for the operation of the
              Website, performance of obligations to the User, or achievement of
              the purposes specified in this Policy. The retention period for
              personal data is determined by the purposes of processing, legal
              requirements, and the period necessary to protect the Controller's
              rights and legitimate interests.
            </p>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              5. Cookies and tracking technologies
            </h2>
            <p>
              The Website may use cookies, web beacons, and other technologies
              that enable the collection and analysis of anonymized data about
              the User's behavior on the Website. The User may change cookie
              settings in their browser; however, disabling cookies may limit
              some Website functionality.
            </p>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              6. User rights
            </h2>
            <p>In accordance with applicable personal data laws, the User has the right to:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Obtain information regarding the processing of their personal data;</li>
              <li>Request rectification, blocking, or deletion of their personal data;</li>
              <li>Withdraw their consent to the processing of personal data.</li>
            </ul>
          </div>

          <div>
            <h2 className="font-display text-xl font-bold text-dark mb-3">
              7. Changes to this Policy
            </h2>
            <p>
              The Controller may, at its sole discretion, amend this Policy at
              any time. The new version of the Policy becomes effective upon its
              publication on the Website. Continued use of the Website by the
              User after the effective date of the new version constitutes the
              User's acceptance of its terms.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
