import { Mail, MessageCircle, ArrowRight } from "lucide-react";

export default function ContactsPage() {
  return (
    <div className="pt-24">
      {/* Hero */}
      <section className="bg-dark py-20 lg:py-28">
        <div className="max-w-[800px] mx-auto px-6 lg:px-10 text-center">
          <span className="text-caption text-accent-orange">CONTACT</span>
          <h1 className="text-h2 text-white mt-4">Get in Touch</h1>
          <p className="text-body-large text-text-muted mt-6 max-w-[600px] mx-auto">
            Reach AIscanAuto for support, billing, and business inquiries.
          </p>
        </div>
      </section>

      {/* Contact cards */}
      <section className="bg-white py-20 lg:py-28">
        <div className="max-w-[700px] mx-auto px-6 lg:px-10">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-surface-light rounded-2xl p-8 text-center hover:-translate-y-1 transition-all duration-300">
              <Mail className="text-accent-blue mx-auto" size={40} />
              <h3 className="font-display text-lg font-bold text-dark mt-4">
                Email Support
              </h3>
              <p className="text-dark/70 text-sm mt-2">
                support@aiscanauto.com
              </p>
              <p className="text-text-muted text-xs mt-1">
                Response within 24 hours
              </p>
            </div>

            <div className="bg-surface-light rounded-2xl p-8 text-center hover:-translate-y-1 transition-all duration-300">
              <MessageCircle className="text-accent-orange mx-auto" size={40} />
              <h3 className="font-display text-lg font-bold text-dark mt-4">
                Community
              </h3>
              <p className="text-dark/70 text-sm mt-2">Discord Server</p>
              <p className="text-text-muted text-xs mt-1">
                Join our community for help
              </p>
            </div>
          </div>

          {/* Contact form */}
          <div className="mt-16 bg-surface-light rounded-2xl p-8 lg:p-10">
            <h2 className="font-display text-2xl font-bold text-dark mb-6">
              Send us a message
            </h2>
            <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-dark font-medium text-sm mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    placeholder="Your name"
                    className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-dark placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-dark font-medium text-sm mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-dark placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="block text-dark font-medium text-sm mb-2">
                  Subject
                </label>
                <select className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-dark focus:outline-none focus:border-accent-blue transition-colors">
                  <option>General Inquiry</option>
                  <option>Technical Support</option>
                  <option>Billing Question</option>
                  <option>Business Partnership</option>
                  <option>Bug Report</option>
                </select>
              </div>
              <div>
                <label className="block text-dark font-medium text-sm mb-2">
                  Message
                </label>
                <textarea
                  rows={5}
                  placeholder="How can we help you?"
                  className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-dark placeholder:text-text-muted focus:outline-none focus:border-accent-blue transition-colors resize-none"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-2 bg-accent-blue text-white font-semibold px-8 py-4 rounded-full hover:bg-accent-blue/90 transition-colors"
              >
                Send Message
                <ArrowRight size={18} />
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}
