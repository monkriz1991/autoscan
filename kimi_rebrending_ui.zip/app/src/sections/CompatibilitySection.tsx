import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

// Car brand names as text labels instead of SVGs for reliability
const carBrands = [
  "Toyota", "Honda", "Ford", "BMW", "Mercedes", "VW", "Nissan", "Hyundai",
  "Chevrolet", "Audi", "Subaru", "Kia", "Mazda", "Volvo", "Jeep", "Lexus",
];

export default function CompatibilitySection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".brand-item", {
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 70%",
          toggleActions: "play none none none",
        },
        y: 30,
        opacity: 0,
        duration: 0.5,
        stagger: 0.05,
        ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-white py-24 lg:py-32" id="compatibility">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Header */}
        <div className="text-center">
          <span className="text-caption text-accent-blue">COMPATIBILITY</span>
          <h2 className="text-h3 text-dark mt-4">
            Works with 10,000+ car models
          </h2>
          <p className="text-dark/80 text-lg max-w-[600px] mx-auto mt-4">
            Any petrol or diesel car manufactured after 1996 (OBD2 standard) +
            any other OBD2-compatible vehicle (1996+)
          </p>
        </div>

        {/* Brand logos grid */}
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-8 lg:gap-10 max-w-[1000px] mx-auto mt-16">
          {carBrands.map((brand, i) => (
            <div
              key={i}
              className="brand-item flex items-center justify-center h-16 opacity-40 hover:opacity-80 transition-opacity grayscale hover:grayscale-0"
            >
              <span className="font-display text-lg font-bold text-dark tracking-tight">
                {brand}
              </span>
            </div>
          ))}
        </div>

        {/* OBD2 badge */}
        <div className="flex justify-center mt-12">
          <span className="inline-block border border-dark text-dark text-caption px-6 py-2 rounded-full">
            Standard OBD2 (1996+)
          </span>
        </div>
      </div>
    </section>
  );
}
