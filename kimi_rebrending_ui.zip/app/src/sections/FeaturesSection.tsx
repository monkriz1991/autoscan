import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Zap, MessageSquare, Gauge, Wifi, Shield, Car } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

const features = [
  { icon: Zap, title: "DTC error scanning", desc: "Read stored & pending fault codes from your ECU." },
  { icon: MessageSquare, title: "AI repair guidance", desc: "Plain-language explanations & repair steps." },
  { icon: Gauge, title: "Live data monitoring", desc: "Fuel trims, O2 sensors, coolant temp, RPM." },
  { icon: Wifi, title: "ELM327 compatible", desc: "USB, Bluetooth, or Wi-Fi adapters. 60s setup." },
  { icon: Shield, title: "Privacy first", desc: "All data stays local. Offline AI mode." },
  { icon: Car, title: "10,000+ models", desc: "Petrol & diesel cars since 1996." },
];

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(".feat-animate", {
        scrollTrigger: { trigger: sectionRef.current, start: "top 75%", toggleActions: "play none none none" },
        y: 30, opacity: 0, duration: 0.6, stagger: 0.08, ease: "power2.out",
      });
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="bg-white py-16 lg:py-20" id="features">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
        {/* Top: Text + Screenshot side by side, aligned */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Left: Text */}
          <div>
            <span className="feat-animate text-caption text-accent-blue block">AI · OBD2</span>
            <h2 className="feat-animate font-display text-3xl lg:text-[2.5rem] font-bold text-dark mt-2 leading-tight">
              OBD2 scanner, ELM327, and AI car diagnostics on desktop
            </h2>
            <p className="feat-animate text-dark/70 mt-4 leading-relaxed">
              Most petrol and diesel cars since 1996 expose a standard OBD-II port.
              With a compatible ELM327 adapter, AIscanAuto reads DTC codes, shows
              readiness monitors, and helps interpret Check Engine warnings. Live
              PID data for fuel trims, O2 sensors, coolant temp, RPM — on Windows,
              macOS, and Linux.
            </p>

            {/* ELM327 inline bar */}
            <div className="feat-animate flex flex-wrap items-center gap-4 mt-6 bg-dark rounded-lg px-5 py-3">
              <p className="text-white/80 text-sm flex-1 min-w-[200px]">
                <strong className="text-white">ELM327</strong> — $10-$30 adapter. Plug in, launch, diagnose in 60s.
              </p>
              <div className="flex items-center gap-4 shrink-0">
                <span className="font-display text-xl font-black text-accent-blue">$10</span>
                <span className="font-display text-xl font-black text-accent-orange">60s</span>
              </div>
            </div>

            {/* Feature cards under text — 3 columns */}
            <div className="grid grid-cols-3 gap-3 mt-6">
              {features.map((f, i) => (
                <div key={i} className="feat-animate bg-surface-light rounded-lg p-4 hover:-translate-y-0.5 transition-all hover:shadow-sm group">
                  <f.icon className="text-accent-blue mb-2 group-hover:scale-110 transition-transform" size={24} strokeWidth={1.5} />
                  <h3 className="font-display text-sm font-bold text-dark">{f.title}</h3>
                  <p className="text-dark/50 text-xs mt-0.5 leading-snug">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Screenshot — full height aligned */}
          <div className="feat-animate lg:sticky lg:top-24">
            <div className="rounded-xl overflow-hidden shadow-xl border border-gray-200">
              <img
                src="/screenshot-diagnostics-ai.png"
                alt="AIscanAuto showing Diagnostics & AI Assistant with GearMind AI chat and Trouble Codes panel"
                className="w-full h-auto"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
